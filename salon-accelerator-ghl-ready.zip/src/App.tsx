import { Hero, Marquee, Nav, Problem } from "./sections/Top";
import {
  Accountability,
  Included,
  Testimonial,
  TrainingDay,
  WhoFor,
} from "./sections/Program";
import {
  About,
  FAQ,
  FitQuiz,
  Outcomes,
  RoiCalculator,
} from "./sections/Convince";
import { Delivery } from "./sections/Delivery";
import { Apply, Footer, StickyCTA } from "./sections/Close";

export default function App() {
  return (
    <div className="min-h-screen bg-cream text-ink">
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <Problem />
        <Included />
        <TrainingDay />
        <Delivery />
        <Accountability />
        <Testimonial />
        <WhoFor />
        <RoiCalculator />
        <About />
        <FitQuiz />
        <Outcomes />
        <FAQ />
        <Apply />
      </main>
      <Footer />
      <StickyCTA />
    </div>
  );
}
