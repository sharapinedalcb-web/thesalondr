import { useState } from "react";
import { CTAButton, Eyebrow, Reveal, Section } from "../components/ui";
import { BRAND } from "../brand";

const INCLUDED = [
  {
    icon: "⏱",
    t: "5-Hour In-Salon Training Session",
    d: "Live, practical training focused on implementation — not theory.",
  },
  {
    icon: "🗣",
    t: "Consultation Mastery",
    d: "Build confidence uncovering client needs and recommending solutions naturally.",
  },
  {
    icon: "🧴",
    t: "Retail Confidence Training",
    d: "Help your team educate and serve clients without feeling pushy or sales-focused.",
  },
  {
    icon: "💎",
    t: "Treatment & High-Ticket Strategy",
    d: "Introduce premium treatments, upgrades and services with confidence.",
  },
  {
    icon: "🗺",
    t: "Client Journey Mapping",
    d: "A consistent, profitable experience from consultation to rebooking and aftercare.",
  },
  {
    icon: "📊",
    t: "KPI & Target Clarity",
    d: "Practical benchmarks so every team member knows exactly what to aim for.",
  },
  {
    icon: "⚙️",
    t: "Systems & Daily Structure",
    d: "Simple systems — including the Daily Huddle — for consistency and accountability.",
  },
  {
    icon: "🔥",
    t: "Team Engagement & Mindset",
    d: "Dismantle limiting beliefs around selling, pricing and communicating value.",
  },
];

const FRAMEWORKS = [
  {
    t: "Principles of C.A.R.E.",
    d: "Care, Attention, Respect and Excellence in every client interaction — the engine behind loyalty and referrals.",
  },
  {
    t: "The 10x10 Rule",
    d: "Consistency and repetition compounded into extraordinary salon performance.",
  },
  {
    t: "Communication Rating",
    d: "Audit your salon's communication channels and close the gaps with clients and team.",
  },
  {
    t: "Goal Setting for Results",
    d: "Clear, actionable goals with tracking so progress becomes measurable, not hopeful.",
  },
  {
    t: "Teamwork & Team Building",
    d: "A culture of collaboration that lifts morale, productivity and salon-wide results.",
  },
  {
    t: "Consultation Cheat Sheet",
    d: "Scripts, prompts and tools so every consultation is delivered at the same high standard.",
  },
];

export function Included() {
  return (
    <Section id="included">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <Eyebrow>What's included</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Everything your team needs to sell with integrity.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-ink/60">
            Delivered in one focused day inside your salon, with workbooks,
            certificates and team gifts to lock the learning in.
          </p>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {INCLUDED.map((c, i) => (
          <Reveal key={c.t} delay={i * 60}>
            <div className="flex h-full flex-col rounded-2xl border border-sand bg-white p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_28px_60px_-34px_rgba(180,85,111,0.6)]">
              <div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-sand text-xl">
                {c.icon}
              </div>
              <h3 className="font-display text-base font-medium leading-snug">
                {c.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{c.d}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className="mt-16 grid items-center gap-10 rounded-[2rem] border border-sand bg-sand/40 p-8 md:p-12 lg:grid-cols-[0.75fr_1.25fr]">
          <img
            src={BRAND.coursePoster}
            alt="The Accelerator Course by The Salon Dr."
            className="mx-auto w-full max-w-xs rounded-2xl shadow-[0_30px_60px_-35px_rgba(33,33,33,0.6)]"
            loading="lazy"
          />
          <div>
            <Eyebrow>The frameworks</Eyebrow>
            <h3 className="mt-4 font-display-light text-3xl sm:text-4xl">
              Tools your team will still be using in 12 months.
            </h3>
            <div className="mt-8 grid gap-x-10 gap-y-6 sm:grid-cols-2">
              {FRAMEWORKS.map((f, i) => (
                <div key={f.t} className="border-t border-rose/30 pt-4">
                  <div className="font-display text-xs font-semibold tracking-widest text-rose-deep">
                    0{i + 1}
                  </div>
                  <h4 className="mt-1 font-display text-lg font-medium">
                    {f.t}
                  </h4>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink/60">
                    {f.d}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}

const AGENDA = [
  {
    time: "Hour 1",
    t: "Mindset & Money Beliefs",
    d: "Why your team resists selling — and how to replace that story with service-led confidence.",
  },
  {
    time: "Hour 2",
    t: "Consultation Mastery",
    d: "The question framework that uncovers real needs, plus objection handling that feels human.",
  },
  {
    time: "Hour 3",
    t: "Retail & Treatment Confidence",
    d: "Natural recommendation language, product storytelling and premium service upgrades.",
  },
  {
    time: "Hour 4",
    t: "Client Journey & C.A.R.E.",
    d: "Map the journey from booking to rebooking so nothing profitable gets skipped.",
  },
  {
    time: "Hour 5",
    t: "KPIs, Huddles & Commitments",
    d: "Set targets, install the Daily Huddle, and every team member signs an accountability card.",
  },
];

export function TrainingDay() {
  const [active, setActive] = useState(0);
  return (
    <Section id="day" className="bg-ink text-cream">
      <Reveal>
        <div className="max-w-2xl">
          <Eyebrow>The training day</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Five hours that change how your salon{" "}
            <span className="font-semibold text-blush">
              talks, sells and serves.
            </span>
          </h2>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-2">
          {AGENDA.map((a, i) => (
            <button
              key={a.t}
              onMouseEnter={() => setActive(i)}
              onClick={() => setActive(i)}
              className={`flex w-full items-center gap-4 rounded-xl border px-5 py-4 text-left transition-all duration-300 ${
                active === i
                  ? "border-blush/70 bg-cream/10"
                  : "border-cream/10 hover:border-cream/30"
              }`}
            >
              <span
                className={`text-[10px] font-semibold uppercase tracking-[0.2em] ${
                  active === i ? "text-blush" : "text-cream/40"
                }`}
              >
                {a.time}
              </span>
              <span className="font-display text-base">{a.t}</span>
            </button>
          ))}
        </div>

        <div className="overflow-hidden rounded-[1.75rem] border border-cream/15 bg-cream/5">
          <img
            src={BRAND.workbooks}
            alt="Salon team with Accelerator Course workbooks"
            className="h-48 w-full object-cover"
            loading="lazy"
          />
          <div className="p-8 md:p-10">
            <div className="text-[11px] font-semibold uppercase tracking-[0.25em] text-blush">
              {AGENDA[active].time}
            </div>
            <h3 className="mt-3 font-display text-2xl">{AGENDA[active].t}</h3>
            <p className="mt-3 text-lg leading-relaxed text-cream/70">
              {AGENDA[active].d}
            </p>
            <div className="mt-7 grid gap-3 border-t border-cream/15 pt-6 text-sm text-cream/60 sm:grid-cols-2">
              <div>✓ Delivered in your salon, on your floor</div>
              <div>✓ Owners and team trained together</div>
              <div>✓ Workbooks, certificates & team gifts</div>
              <div>✓ Scripts ready to use next morning</div>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}

export function Accountability() {
  return (
    <Section id="accountability">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <Reveal>
          <div className="relative">
            <div className="overflow-hidden rounded-[2rem] rounded-bl-[6rem] border-4 border-white shadow-[0_40px_80px_-45px_rgba(33,33,33,0.55)]">
              <img
                src={BRAND.accountability}
                alt="The Salon Dr. 30-day accountability session"
                className="h-[24rem] w-full object-cover sm:h-[30rem]"
                loading="lazy"
              />
            </div>
            <img
              src={BRAND.commitmentCard}
              alt="Personalised accountability commitment card"
              className="absolute -right-4 -bottom-8 w-36 rotate-3 rounded-xl border-4 border-white shadow-2xl sm:w-44"
              loading="lazy"
            />
            <div className="absolute -left-4 top-6 rounded-2xl bg-rose px-5 py-4 text-ink shadow-xl">
              <div className="font-display text-3xl font-semibold">30</div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.18em]">
                Day accountability
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div>
            <Eyebrow>The point of difference</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Most training ends at 5pm. This one keeps going.
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-ink/70">
              Thirty days after your training, you sit down with Sonia on Zoom
              and review your personalised accountability card — the goals your
              team set, the progress made, and the roadblocks in the way.
            </p>
            <ul className="mt-7 space-y-4">
              {[
                "Review every commitment made on training day",
                "Troubleshoot the habits that didn't stick",
                "Reset targets and celebrate the wins",
                "Lock in sustainable sales habits for good",
              ].map((x) => (
                <li key={x} className="flex gap-3 text-ink/75">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-rose text-xs text-white">
                    ✓
                  </span>
                  <span>{x}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 rounded-2xl border-l-4 border-rose bg-sand/50 p-6 font-display text-lg leading-relaxed">
              “True growth comes from continuous improvement and
              accountability.”
              <span className="mt-2 block text-sm text-ink/50">
                — Sonia Tomas, The Salon Dr.
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

const AUDIENCE = [
  {
    t: "Salon Owners & Managers",
    d: "Who want to lead teams more effectively, increase profitability and elevate the client experience.",
  },
  {
    t: "Aspiring Salon Leaders",
    d: "Developing the skills to step into managerial roles and drive salon success.",
  },
  {
    t: "Experienced Hairdressers",
    d: "Ready to grow beyond technical skill into business growth, client satisfaction and collaboration.",
  },
  {
    t: "Whole Salon Teams",
    d: "Committed to common goals, better communication and a thriving salon environment.",
  },
];

export function WhoFor() {
  return (
    <Section className="bg-sand/40">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>Who it's for</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Built for owners and staff — because the gap lives between them.
          </h2>
        </div>
      </Reveal>
      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {AUDIENCE.map((a, i) => (
          <Reveal key={a.t} delay={i * 80}>
            <div className="h-full rounded-2xl bg-white p-7 shadow-[0_20px_50px_-40px_rgba(33,33,33,0.7)]">
              <div className="font-display text-4xl font-semibold text-blush">
                0{i + 1}
              </div>
              <h3 className="mt-3 font-display text-lg font-medium leading-snug">
                {a.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{a.d}</p>
            </div>
          </Reveal>
        ))}
      </div>
      <Reveal>
        <div className="mt-12 text-center">
          <CTAButton className="px-8 py-4 text-base">
            Book Your Salon's Training Day
          </CTAButton>
        </div>
      </Reveal>
    </Section>
  );
}

export function Testimonial() {
  return (
    <Section className="bg-ink text-cream">
      <Reveal>
        <div className="grid items-center gap-10 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <Eyebrow>What salons are saying</Eyebrow>
            <blockquote className="mt-6 font-display-light text-3xl leading-snug sm:text-4xl">
              “I'm blown away! We have all hit our target of{" "}
              <span className="font-semibold text-blush">$2,346 in retail</span>{" "}
              in one week. The team are just so excited and loving the feedback
              clients are giving us! You're amazing! Thank you!”
            </blockquote>
            <div className="mt-7 flex items-center gap-4">
              <span className="h-px w-12 bg-blush" />
              <div>
                <div className="font-display font-medium">Shenade</div>
                <div className="text-sm text-cream/55">Hair Shenanigans</div>
              </div>
            </div>
          </div>
          <img
            src={BRAND.teamSession}
            alt="Salon team at an Accelerator Course training session"
            className="h-72 w-full rounded-[2rem] object-cover lg:h-96"
            loading="lazy"
          />
        </div>
      </Reveal>
    </Section>
  );
}
