import { useEffect, useState } from "react";
import { CTAButton, Eyebrow, Reveal, Section } from "../components/ui";
import { BRAND } from "../brand";

export function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <a href="#top" className="flex items-center gap-3">
      <span
        className={`grid h-12 w-12 place-items-center overflow-hidden rounded-full ${
          dark ? "bg-cream" : "bg-white"
        } shadow-sm`}
      >
        <img
          src={BRAND.logo}
          alt="The Salon Dr. logo"
          className="h-10 w-10 object-contain"
        />
      </span>
      <span className="leading-tight">
        <span
          className={`block font-display text-sm font-semibold uppercase tracking-[0.18em] ${
            dark ? "text-cream" : "text-ink"
          }`}
        >
          The Salon Dr.
        </span>
        <span
          className={`block text-[10px] uppercase tracking-[0.22em] ${
            dark ? "text-blush" : "text-rose-deep"
          }`}
        >
          Accelerator Course
        </span>
      </span>
    </a>
  );
}

export function Heartbeat({ className = "" }: { className?: string }) {
  return (
    <img
      src={BRAND.heartbeat}
      alt=""
      aria-hidden
      className={`mx-auto h-8 w-auto max-w-full object-contain opacity-90 ${className}`}
      loading="lazy"
    />
  );
}

export function Nav() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    ["What's Included", "#included"],
    ["The Day", "#day"],
    ["In-Salon or Online", "#delivery"],
    ["Accountability", "#accountability"],
    ["Is It For Me?", "#fit"],
  ];

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        solid
          ? "bg-cream/90 py-2.5 shadow-[0_1px_0_rgba(33,33,33,0.08)] backdrop-blur-xl"
          : "py-4"
      }`}
    >
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-5">
        <Logo />

        <nav className="hidden items-center gap-7 lg:flex">
          {links.map(([label, href]) => (
            <a
              key={href}
              href={href}
              className="text-sm font-medium text-ink/70 transition hover:text-rose-deep"
            >
              {label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <CTAButton className="hidden px-5 py-3 sm:inline-flex">
            Book a Discovery Call
          </CTAButton>
          <button
            onClick={() => setOpen((o) => !o)}
            aria-label="Menu"
            className="grid h-10 w-10 place-items-center rounded-full border border-ink/20 lg:hidden"
          >
            <span className="text-lg">{open ? "✕" : "☰"}</span>
          </button>
        </div>
      </div>

      {open && (
        <div className="mx-5 mt-3 rounded-2xl border border-sand bg-cream p-4 shadow-xl lg:hidden">
          {links.map(([label, href]) => (
            <a
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className="block border-b border-sand py-3 text-sm font-medium last:border-0"
            >
              {label}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pb-16 pt-28 md:pt-36">
      <div className="pointer-events-none absolute -right-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-sand blur-3xl opacity-80" />
      <div className="pointer-events-none absolute -left-40 top-80 h-96 w-96 rounded-full bg-blush/30 blur-3xl" />

      <div className="relative mx-auto grid w-full max-w-6xl items-center gap-14 px-5 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <Reveal>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-blush/60 bg-white/80 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-ink/70 backdrop-blur">
              <span className="h-2 w-2 animate-pulse rounded-full bg-rose" />
              In-Salon or Live Online · Australia Wide
            </div>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="font-display-light text-[2.5rem] leading-[1.08] sm:text-[3.6rem]">
              If I walked into your salon today, I'd find{" "}
              <span className="relative inline-block">
                <span className="relative z-10 font-semibold text-rose-deep">
                  thousands of dollars
                </span>
                <span className="absolute inset-x-0 bottom-1 z-0 h-3 bg-blush/50" />
              </span>{" "}
              you're unknowingly leaving behind.
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink/70">
              The <strong>Accelerator Course</strong> is a 5-hour, hands-on
              training day delivered <strong>in your salon or live online</strong>{" "}
              by Sonia Tomas — plus a{" "}
              <strong>30-day accountability session</strong> so the habits
              actually stick. More retail. More treatments. No more sounding
              “salesy”.
            </p>
          </Reveal>

          <Reveal delay={240}>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <CTAButton className="px-8 py-4 text-base">
                Secure Your Salon's Date
              </CTAButton>
              <a
                href="#included"
                className="text-sm font-semibold text-ink/70 underline decoration-blush decoration-2 underline-offset-8 transition hover:text-rose-deep"
              >
                See exactly what's included
              </a>
            </div>
          </Reveal>

          <Reveal delay={320}>
            <div className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-sand pt-7">
              {[
                ["35+ yrs", "In the hairdressing industry"],
                ["$5M+", "Annual revenue as a BDM"],
                ["30 days", "Follow-up accountability"],
              ].map(([big, small]) => (
                <div key={big}>
                  <div className="font-display text-2xl font-semibold text-ink">
                    {big}
                  </div>
                  <div className="text-xs leading-snug text-ink/55">
                    {small}
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <Reveal delay={200}>
          <div className="relative">
            <div className="overflow-hidden rounded-[2rem] rounded-tr-[6rem] border-4 border-white shadow-[0_40px_80px_-40px_rgba(33,33,33,0.5)]">
              <img
                src={BRAND.soniaPortrait}
                alt="Sonia Tomas, founder of The Salon Dr."
                className="h-[26rem] w-full object-cover object-top sm:h-[32rem]"
                loading="eager"
              />
            </div>
            <div className="animate-floaty absolute -bottom-7 -left-4 w-60 rounded-2xl border border-sand bg-white p-5 shadow-xl sm:-left-10">
              <div className="text-[10px] font-semibold uppercase tracking-[0.2em] text-ink/45">
                The real problem
              </div>
              <p className="mt-2 text-sm leading-snug text-ink/80">
                “Retail isn't a product problem. It's a{" "}
                <span className="font-semibold text-rose-deep">confidence</span>{" "}
                problem.”
              </p>
              <div className="mt-3 text-xs text-ink/50">— Sonia Tomas</div>
            </div>
            <div className="absolute -right-3 top-8 hidden rounded-2xl border border-sand bg-white/95 px-4 py-3 text-center shadow-lg backdrop-blur sm:block">
              <div className="font-display text-xl font-semibold text-rose-deep">
                C.A.R.E.
              </div>
              <div className="text-[10px] uppercase tracking-[0.15em] text-ink/50">
                Framework included
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      <div className="relative mt-16 px-5">
        <Heartbeat />
        <p className="mt-4 text-center font-display text-lg text-ink/60 sm:text-xl">
          Diagnose and prescribe the right solutions for your salon.
        </p>
      </div>
    </section>
  );
}

export function Marquee() {
  const items = [
    "Consultation Mastery",
    "Retail Confidence",
    "High-Ticket Treatments",
    "Client Journey Mapping",
    "KPIs & Targets",
    "The Daily Huddle",
    "The 10x10 Rule",
    "Goal Setting for Results",
    "Team Engagement & Mindset",
  ];
  const row = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-ink/10 bg-ink py-4 text-cream">
      <div className="animate-marquee flex w-max gap-10 whitespace-nowrap">
        {row.map((t, i) => (
          <span
            key={i}
            className="flex items-center gap-10 text-xs font-semibold uppercase tracking-[0.25em] text-cream/75"
          >
            {t} <span className="text-blush">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

const PAINS = [
  {
    t: "Shelves full of dust-collecting stock",
    d: "Thousands tied up in retail that never moves — and a team that won't touch it.",
  },
  {
    t: "“I don't want to be pushy”",
    d: "Your stylists freeze at recommendation time, so clients buy their shampoo at the chemist.",
  },
  {
    t: "Inconsistent consultations",
    d: "Every chair does it differently. Misunderstandings, redo's and quiet Google reviews follow.",
  },
  {
    t: "No KPIs, no accountability",
    d: "Nobody actually knows their numbers, so nobody is chasing them.",
  },
  {
    t: "Treatments never get offered",
    d: "Premium services sit on the menu while average spend flatlines.",
  },
  {
    t: "Training that fades in a week",
    d: "You've paid for education before. Everyone loved it. Nothing changed.",
  },
];

export function Problem() {
  return (
    <Section id="problem" className="grain">
      <Reveal>
        <div className="max-w-2xl">
          <Eyebrow>Sound familiar?</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Your salon isn't short on talent.
            <span className="block text-ink/40">It's short on a system.</span>
          </h2>
          <p className="mt-5 text-lg text-ink/65">
            More clients aren't always the answer. The revenue is already
            sitting inside your salon — in conversations that never happen.
          </p>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {PAINS.map((p, i) => (
          <Reveal key={p.t} delay={i * 70}>
            <div className="group h-full rounded-2xl border border-sand bg-white/70 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-rose hover:bg-white hover:shadow-[0_24px_50px_-30px_rgba(180,85,111,0.5)]">
              <div className="mb-4 grid h-9 w-9 place-items-center rounded-full border border-rose/50 text-rose-deep transition group-hover:bg-rose group-hover:text-white">
                ✕
              </div>
              <h3 className="font-display text-lg font-medium leading-snug">
                {p.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{p.d}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={120}>
        <div className="mt-14 grid items-center gap-0 overflow-hidden rounded-[2rem] bg-ink text-cream md:grid-cols-2">
          <img
            src={BRAND.trainingRoom}
            alt="Sonia Tomas delivering in-salon training to a hair team"
            className="h-72 w-full object-cover md:h-full"
            loading="lazy"
          />
          <div className="p-8 md:p-12">
            <Eyebrow>The fix</Eyebrow>
            <h3 className="mt-4 font-display-light text-3xl leading-snug">
              One day in your salon. Built around{" "}
              <span className="font-semibold text-blush">your</span> team, your
              menu, your numbers.
            </h3>
            <p className="mt-4 text-cream/70">
              No generic seminar. No hotel conference room. Sonia trains your
              owners <em>and</em> your staff together — on your salon floor or
              live over Zoom — with scripts and systems they use the very next
              morning.
            </p>
            <CTAButton variant="light" className="mt-7">
              Check Availability
            </CTAButton>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
